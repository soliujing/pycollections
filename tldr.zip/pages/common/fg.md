# fg

> Run jobs in foreground.

- Bring most recently suspended background job to foreground:

`fg`

- Bring a specific job to foreground:

`fg %{{job_id}}`
