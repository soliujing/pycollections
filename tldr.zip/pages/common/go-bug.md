# go bug

> Report a bug.
> More information: <https://golang.org/cmd/go/#hdr-Start_a_bug_report>.

- Open a web page to start a bug report:

`go bug`
