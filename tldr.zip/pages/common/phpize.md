# phpize

> Prepare a PHP extension for compiling.
> More information: <https://www.php.net/manual/install.pecl.phpize>.

- Prepare the PHP extension in the current directory for compiling:

`phpize`

- Delete files previously created by phpize:

`phpize --clean`
