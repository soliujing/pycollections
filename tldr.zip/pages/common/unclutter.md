# unclutter

> Hides the mouse cursor.

- Hide mouse cursor after 3 seconds:

`unclutter -idle {{3}}`
